# Bellman-Ford Algorithm
def bellman_ford(graph, vertices, edges, source):
    dist = [float('inf')] * vertices
    dist[source] = 0

    for _ in range(vertices - 1):
        for u, v, w in edges:
            if dist[u] != float('inf') and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w

    # Check for negative weight cycles
    for u, v, w in edges:
        if dist[u] != float('inf') and dist[u] + w < dist[v]:
            print("Graph contains a negative weight cycle")
            return None

    return dist

# Example usage:
vertices = 5
edges = [
    (0, 1, -1),
    (0, 2, 4),
    (1, 2, 3),
    (1, 3, 2),
    (1, 4, 2),
    (3, 2, 5),
    (3, 1, 1),
    (4, 3, -3)
]
source = 0
distances = bellman_ford(None, vertices, edges, source)
print("Bellman-Ford distances:", distances)


# Dijkstra Algorithm
import heapq

def dijkstra(graph, vertices, source):
    dist = [float('inf')] * vertices
    dist[source] = 0
    pq = [(0, source)]  # (distance, vertex)

    while pq:
        current_dist, u = heapq.heappop(pq)
        if current_dist > dist[u]:
            continue
        for v, weight in graph[u]:
            if dist[u] + weight < dist[v]:
                dist[v] = dist[u] + weight
                heapq.heappush(pq, (dist[v], v))
    return dist

# Example usage:
graph = {
    0: [(1, 4), (2, 1)],
    1: [(3, 1)],
    2: [(1, 2), (3, 5)],
    3: []
}
vertices = 4
source = 0
distances = dijkstra(graph, vertices, source)
print("Dijkstra distances:", distances)
